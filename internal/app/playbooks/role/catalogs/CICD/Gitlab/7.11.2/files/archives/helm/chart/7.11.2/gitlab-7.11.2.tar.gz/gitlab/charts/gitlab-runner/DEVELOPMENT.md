# Developement

## Running tests

1. install helm unittest plugin:
    ```bash
    helm plugin install https://github.com/helm-unittest/helm-unittest.git
    ```
2. run tests:
    ```bash
    helm unittest .
    ```